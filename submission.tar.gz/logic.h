#ifndef LOGIC_H
#define LOGIC_H

#include "main.h"

void resetGameState(Player *p1, Player *oldplayer, Rock *rocks, Rock *initial_state, enum gba_state *state, int *init, int *frame, struct object *hidden_machine, int* frameCount, int level_length);
int collision(Player *p1, Rock *rocks, struct object hidden_machine, u32 button, int rocksLength, enum gba_state *state);
void playermovement(Player *oldplayer, Player *p1, u32 button, int *frame, Rock *rocks, struct object hidden_machine, int rocksLength, enum gba_state *state);
void animation(int frame);
#endif // LOGIC_H