Welcome to Pokemon: A Test of Strength
Reach the Hidden Machine, moving boulders around! (hidden machine is the disk)
Controls:
Arrow keys - move up, left, down, right respectively
Start -> move past title screens
Select -> Reset

Have Fun!
