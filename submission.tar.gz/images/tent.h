/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=16x16 tent tent.png 
 * Time-stamp: Tuesday 04/02/2024, 06:16:24
 * 
 * Image Information
 * -----------------
 * tent.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TENT_H
#define TENT_H

extern const unsigned short tent[256];
#define TENT_SIZE 512
#define TENT_LENGTH 256
#define TENT_WIDTH 16
#define TENT_HEIGHT 16

#endif

