/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 blackmage2 BlackMage-Victory.png 
 * Time-stamp: Wednesday 04/03/2024, 00:53:40
 * 
 * Image Information
 * -----------------
 * BlackMage-Victory.png 36@52
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLACKMAGE2_H
#define BLACKMAGE2_H

extern const unsigned short BlackMageVictory[1872];
#define BLACKMAGEVICTORY_SIZE 3744
#define BLACKMAGEVICTORY_LENGTH 1872
#define BLACKMAGEVICTORY_WIDTH 36
#define BLACKMAGEVICTORY_HEIGHT 52

#endif

