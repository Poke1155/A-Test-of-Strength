/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 saladrom2 saladrom-2(1).png 
 * Time-stamp: Tuesday 04/02/2024, 23:08:29
 * 
 * Image Information
 * -----------------
 * saladrom-2(1).png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SALADROM2_H
#define SALADROM2_H

extern const unsigned short saladrom21[38400];
#define SALADROM21_SIZE 76800
#define SALADROM21_LENGTH 38400
#define SALADROM21_WIDTH 240
#define SALADROM21_HEIGHT 160

#endif

