/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 blackmage1 BlackMage-Victory1.png 
 * Time-stamp: Wednesday 04/03/2024, 00:53:29
 * 
 * Image Information
 * -----------------
 * BlackMage-Victory1.png 36@52
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLACKMAGE1_H
#define BLACKMAGE1_H

extern const unsigned short BlackMageVictory1[1872];
#define BLACKMAGEVICTORY1_SIZE 3744
#define BLACKMAGEVICTORY1_LENGTH 1872
#define BLACKMAGEVICTORY1_WIDTH 36
#define BLACKMAGEVICTORY1_HEIGHT 52

#endif

