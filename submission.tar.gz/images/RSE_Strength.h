/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 RSE_Strength RSE_Strength.png 
 * Time-stamp: Tuesday 04/02/2024, 02:52:04
 * 
 * Image Information
 * -----------------
 * RSE_Strength.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RSE_STRENGTH_H
#define RSE_STRENGTH_H

extern const unsigned short RSE_Strength[256];
#define RSE_STRENGTH_SIZE 512
#define RSE_STRENGTH_LENGTH 256
#define RSE_STRENGTH_WIDTH 16
#define RSE_STRENGTH_HEIGHT 16

#endif

