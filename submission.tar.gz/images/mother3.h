/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 mother3 mother3.png 
 * Time-stamp: Sunday 03/31/2024, 05:47:16
 * 
 * Image Information
 * -----------------
 * mother3.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MOTHER3_H
#define MOTHER3_H

extern const unsigned short mother3[38400];
#define MOTHER3_SIZE 76800
#define MOTHER3_LENGTH 38400
#define MOTHER3_WIDTH 240
#define MOTHER3_HEIGHT 160

#endif

