/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=16x16 HM04 HM04.png 
 * Time-stamp: Tuesday 04/02/2024, 04:35:36
 * 
 * Image Information
 * -----------------
 * HM04.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HM04_H
#define HM04_H

extern const unsigned short HM04[256];
#define HM04_SIZE 512
#define HM04_LENGTH 256
#define HM04_WIDTH 16
#define HM04_HEIGHT 16

#endif

