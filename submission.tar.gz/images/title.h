/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 title tiele.png 
 * Time-stamp: Tuesday 04/02/2024, 23:11:00
 * 
 * Image Information
 * -----------------
 * tiele.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE_H
#define TITLE_H

extern const unsigned short tiele[38400];
#define TIELE_SIZE 76800
#define TIELE_LENGTH 38400
#define TIELE_WIDTH 240
#define TIELE_HEIGHT 160

#endif

